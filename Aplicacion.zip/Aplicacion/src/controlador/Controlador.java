package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.EstudianteVO;
import modelo.Registrar;
import vista.Vista;

public class Controlador implements ActionListener{
    private EstudianteVO student;
    private Registrar registro;
    private Vista view;
    
    public Controlador(EstudianteVO student, Registrar registro, Vista view){
        this.student = student;
        this.registro = registro;
        this.view = view;
        this.view.btn_Registro.addActionListener(this);
        this.view.btn_Reset.addActionListener(this);
        this.view.btn_Salir.addActionListener(this);
    }

    public void iniciar(){
        view.setTitle("Registro de estudiantes");
        view.setResizable(false);
        view.setLocationRelativeTo(null);
    }
    public void Limpiar(){
            view.txt_Codigo.setText("");
            view.txt_Primer_Nombre.setText("");
            view.txt_Segundo_Nombre.setText("");
            view.txt_Primer_Apellido.setText("");
            view.txt_Segundo_Apellido.setText("");
            view.txt_Programa.setText("");
    }
    @Override
    public void actionPerformed(ActionEvent e) {        
        if(view.btn_Registro == e.getSource()){
        student.setCodigo(view.txt_Codigo.getText());
        student.setPrimer_Nombre(view.txt_Primer_Nombre.getText());
        student.setSegundo_Nombre(view.txt_Segundo_Nombre.getText());
        student.setPrimer_Apellido(view.txt_Primer_Apellido.getText());
        student.setSegundo_Apellido(view.txt_Segundo_Apellido.getText());
        student.setPrograma(view.txt_Programa.getText());
        
        if(registro.Registrar(student)){
            JOptionPane.showMessageDialog(null, "El registro se hizo exitosamente!");
            Limpiar();
        }else{
               JOptionPane.showMessageDialog(null, "Ha ocurrido un error al guardar");
            }
        }
        
        if(view.btn_Reset == e.getSource()){
            Limpiar();
        }
        if(view.btn_Salir == e.getSource()){
            System.exit(0);
        }
        
    }
}
