package main;

import controlador.Controlador;
import modelo.EstudianteVO;
import modelo.Registrar;
import vista.Vista;


public class Main {
    public static void main(String[] args) {
        EstudianteVO student = new EstudianteVO();
        Vista view = new Vista();
        Registrar Registro = new Registrar();
        Controlador control = new Controlador(student, Registro, view);
        control.iniciar();
        view.setVisible(true);
        
        

        
    }
}
