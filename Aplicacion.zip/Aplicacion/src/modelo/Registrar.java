    package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Registrar extends Conexion{
    public boolean Registrar(EstudianteVO E){
        PreparedStatement pst = null;
        Connection con = getConnection();
        String sql = "INSERT INTO ESTUDIANTES(CODIGO, PRIMER_NOMBRE, SEGUNDO_NOMBRE, "
                + "PRIMER_APELLIDO, SEGUNDO_APELLIDO, PROGRAMA) VALUES (?, ?, ?, ? ,?, ?)";
        try{
            pst = con.prepareStatement(sql);
            pst.setString(1, E.getCodigo());
            pst.setString(2, E.getPrimer_Nombre());
            pst.setString(3, E.getSegundo_Nombre());
            pst.setString(4, E.getPrimer_Apellido());
            pst.setString(5, E.getSegundo_Apellido());
            pst.setString(6, E.getPrograma());
            pst.execute();
            return true;
            
        }catch(Exception e){
            System.out.println("Error al registrar: " + e);
            return false;
        }
        
    }
}
