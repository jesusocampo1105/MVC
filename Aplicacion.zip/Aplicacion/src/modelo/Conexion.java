package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private final String URL = "jdbc:mysql://localhost:3306/universidad";
    private final String USER = "root";
    private final String PASS = "";
    private Connection con;
    public Connection getConnection (){
        try{
            con = DriverManager.getConnection(URL, USER, PASS);
        }catch(SQLException e){
            System.out.println("Error al conectarse: " + e);
        }
        return con;
    }
}
